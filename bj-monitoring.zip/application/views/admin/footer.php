<footer>
  <div class="pull-right">
    <p style="text-align:center">&copy; 2016  <a href="http://www.garuda-indonesia.com">PT Bank Jatim (Persero) Tbk</a> </p>
        
  </div>
  <div class="clearfix"></div>
</footer>