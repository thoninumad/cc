<div class="navbar nav_title" style="border: 0;">
  <a href="index.php" class="site_title" >Bank Jatim</span></a>
</div>
<div class="clearfix"></div>

<br />
<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
  <div class="menu_section">
    <div class="clearfix"></div>
    <ul class="nav side-menu">

      <li><a ><i class="fa fa-home"></i> Beranda <span class="fa fa-chevron-down"></span></a>
        <ul class="nav child_menu">
          <li><a href="index.php">Progress Submission</a></li>
        </ul>
      </li>
      <li><a ><i class="fa fa-cogs"></i> Culture Programs <span class="fa fa-chevron-down"></span></a>
        <ul class="nav child_menu">
          <li><a href="quick_program.php">List Program</a></li>
          <li><a href="add_program.php">Tambah Program</a></li>
          <li><a>Progress Program<span class="fa fa-chevron-down"></span></a>
            <ul class="nav child_menu">
              <li class="sub_menu"><a href="progress_program.php">Progress Unit</a>
              </li>
              <li class="sub_menu"><a href="progress_program_dir.php">Progress Direktorat</a>
              </li>
            </ul>
          </li>
        </ul>
      </li>
      <li><a ><i class="fa fa-home"></i> Voice of Customer <span class="fa fa-chevron-down"></span></a>
        <ul class="nav child_menu">
          <li><a href="dashboard.php">Voice Index</a></li>
          <li><a href="import_new.php">Tambah Data Baru</a></li>
        </ul>
      </li>
      <li><a ><i class="fa fa-user"></i> Users <span class="fa fa-chevron-down"></span></a>
        <ul class="nav child_menu">
          <li><a href="users.php">Daftar User</a></li>
          <li><a href="units.php">Akun Unit</a></li>
        </ul>
      </li>
    </ul>
  </div>
</div>