<footer class="main-footer">
    <div class="pull-right hidden-xs">
    </div>
    <strong>Copyright &copy; 2017 Bank Jatim</a>.</strong> All rights
    reserved.
</footer>