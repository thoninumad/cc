<?php get_header(); ?>

<div id="main">
	
	
    
   	<div class="content right">
    	        
         <div class="single">
		
			<div class="breadcrumbs">
				<?php wp_breadcrumb(); ?>
			</div>
			
			<?php if (have_posts()) : ?>
              <h3 class="sdtitle">
			  	Search result for "<?php the_search_query(); ?>" found
				<?php
					global $wp_query;
					$total_results = $wp_query->found_posts;
					echo $total_results;
				?>
				related posts
			  </h3>
                
                <div class="p1">
                	<?php while (have_posts()) : the_post(); ?>
                    <div class="listnews">
                        <div class="title"><h2><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2></div>
                        <div class="entry"><?php the_excerpt(); ?></div>
                        <div class="info">Posted in <?php the_time('d.m.Y') ?> | <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">readmore</a></div>
                        <div class="clear"></div>
                    </div>
					<?php endwhile; ?>
                </div>
				
				<?php else : ?>
				<h3 class="sdtitle">No posts found for "<?php the_search_query(); ?>". Try a different search.</h3>
				
			<?php endif; ?>
			
			<div class="pages">
			<?php 
				if (function_exists("paginate")) {
					paginate(); 
				}
			?>
			</div>
		</div>
              
        
    </div>
    <?php get_sidebar(); ?>
    <div class="clear"></div>
    
</div>

<?php get_footer(); ?>