<?php get_header(); ?>

<div id="main">
	
    
    
    <div class="content right">
	
        <div class="single">
		
			<div class="breadcrumbs">
				<?php wp_breadcrumb(); ?>
			</div>
		
			<?php if (have_posts()) : ?>
			<?php while (have_posts()) : the_post(); ?>
				
            <div class="title"><h1><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h1></div>
                        
            <div class="info">Ditulis pada tanggal <?php the_time('j F Y') ?>, oleh <?php the_author(); ?>, pada kategori <?php the_category(', '); ?></div>
                
			<div class="entry">
				<?php the_content(); ?>
				<div class="clear"></div><!-- selalu ada pada akhir entry -->
			</div>
			
			<div class="execute">
            	<?php if(function_exists('save_htm')) save_htm(); ?>
				<?php if(function_exists('save_doc')) save_doc(); ?>
				<?php if(function_exists('save_pdf')) save_pdf(); ?>
				<?php if(function_exists('save_txt')) save_txt(); ?>
			</div>
			
			<?php endwhile; ?>
			<?php endif; ?>			
                
            <div class="clear"></div>
        </div>
        
    </div>
    <?php get_sidebar(); ?>
    <div class="clear"></div>
    
</div>

<?php get_footer(); ?>