<?php get_header(); ?>

<div id="main">



    <div class="content right">

      <!--<div class="flexslider">
      		<img src="<?php //header_image(); ?>" width="<?php //echo HEADER_IMAGE_WIDTH; ?>" height="<?php //echo HEADER_IMAGE_HEIGHT; ?>" alt="" />
      </div>-->
      
      <!--------------------------------------------------------------
      ----------------------------------------------------------------
      ---- MASUKAN KODE METASLIDER DIANTARA TAG SLIDER BERIKUT : -----
      ---- HAPUS TANDA "//" DAN UBAH ID SESUAI KODE METASLIDER  ------
      ----------------------------------------------------------------
      ---------------------------------------------------------------->
      <div class="slider">
      		
			<?php //echo do_shortcode("[metaslider id=65]"); ?>
            
      </div>
      <!--------------------------------------------------------------
      ----------------------------------------------------------------
      ----------------------------------------------------------------
      ---------------------------------------------------------------->
    	<div class="home-news">
        	<?php
				$link_request = $_SERVER['REDIRECT_URL'];
				preg_match('/\/(en)\/*/i', $link_request,$match);
				$language = (isset($match[1])) ? $match[1] : 'indo';


				if($language == 'en'){?>
						<h3 class="blocktitle">Top News<a href="<?php bloginfo('url'); ?>/category/berita/feed/" class="rss">RSS</a></h3>
				<?php }
				else{?>
						<h3 class="blocktitle">Berita Terbaru<a href="<?php bloginfo('url'); ?>/category/berita/feed/" class="rss">RSS</a></h3>

				<?php }
			?>



			<?php if (have_posts()) : ?>
				<?php query_posts('cat=1&showposts=3'); ?>
				<?php while (have_posts()) : the_post(); ?>

					<div class="block">
						<div class="text left">
							<div class="title"><h2><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2></div>
							<div class="info">Posted in <?php the_time('d M Y') ?> | <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">readmore</a></div>
							<div class="entry"><?php the_excerpt(); ?></div>
						</div>
						<div class="clear"></div>
					</div>

				<?php endwhile; ?>
			<?php endif; ?>

            <a href="<?php bloginfo('url'); ?>/category/berita/" style="font-style:italic; text-align:right; display:block">&raquo; Berita Lainnya</a>
        </div>
        <div class="container">
        <div class="other-list left" style="margin-left:25px">
        	<?php
				$link_request = $_SERVER['REDIRECT_URL'];
				preg_match('/\/(en)\/*/i', $link_request,$match);
				$language = (isset($match[1])) ? $match[1] : 'indo';


				if($language == 'en'){?>
						<h3 class="blocktitle">Announcements<a href="<?php bloginfo('url')?>/category/pengumuman/feed/" class="rss">RSS</a></h3>
				<?php }
				else{?>
						<h3 class="blocktitle">Pengumuman<a href="<?php bloginfo('url')?>/category/pengumuman/feed/" class="rss">RSS</a></h3>
				<?php }
			?>

            <div class="block">
            	<ul>
                	<?php
						$recentPosts = new WP_Query();
						$recentPosts->query('showposts=3&cat=4');
					?>
					<?php while ($recentPosts->have_posts()) : $recentPosts->the_post(); ?>
						<li><?php the_time('d.m.Y') ?>&nbsp;-&nbsp;<a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a></li>
					<?php endwhile; ?>
                </ul>
                <a href="<?php bloginfo('url'); ?>/category/pengumuman/" style="font-style:italic; text-align:right; display:block">&raquo; Pengumuman Lainnya</a>
            </div>

        </div>

        <div class="other-list left" style="margin-left:20px">
        	<?php
				$link_request = $_SERVER['REDIRECT_URL'];
				preg_match('/\/(en)\/*/i', $link_request,$match);
				$language = (isset($match[1])) ? $match[1] : 'indo';


				if($language == 'en'){?>
						<h3 class="blocktitle">Activities<a href="<?php bloginfo('url')?>/category/kegiatan/feed/" class="rss">RSS</a></h3>
				<?php }
				else{?>
						<h3 class="blocktitle">Kegiatan<a href="<?php bloginfo('url')?>/category/kegiatan/feed/" class="rss">RSS</a></h3>
				<?php }
			?>

            <div class="block">
            	<ul>
                	<?php
						$recentPosts = new WP_Query();
						$recentPosts->query('showposts=3&cat=3');
					?>
					<?php while ($recentPosts->have_posts()) : $recentPosts->the_post(); ?>
						<li><?php the_time('d.m.Y') ?>&nbsp;-&nbsp;<a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a></li>
					<?php endwhile; ?>
                </ul>
                <a href="<?php bloginfo('url'); ?>/category/kegiatan/" style="font-style:italic; text-align:right; display:block">&raquo; Kegiatan Lainnya</a>
            </div>
            <div class="clear"></div>
        </div>
        </div>
        <div class="clear"></div>

    </div>
    <?php get_sidebar(); ?>
    <div class="clear"></div>

</div>

<?php get_footer(); ?>