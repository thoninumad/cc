	<div class="sidebar left">
			
			<div class="block">
            	<?php
					//echo "<pre>";
					//print_r ($_SERVER);
					//echo "</pre>";
					$link_request = $_SERVER['REDIRECT_URL'];
					preg_match('/\/(en)\/*/i', $link_request,$match);
					$language = (isset($match[1])) ? $match[1] : 'indo';
					
			
					if($language == 'en'){
						echo '<h3 class="sdtitle">Search</h3>';
					}
					else{
						echo '<h3 class="sdtitle">Pencarian</h3>';
					}
					
					//print_r ($_SERVER);
				?>
            	
				<form method="get" id="search-form" action="<?php bloginfo('home'); ?>/">
					<input type="text" value="" name="s" id="searchinput" style="width:145px;" />
					<input type="submit" id="searchsubmit" value="search" />
				</form>
            </div>
			
			<?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar('second-area') ) : else : ?>
			<div class="block">
            	<?php
					//echo "<pre>";
					//print_r ($_SERVER);
					//echo "</pre>";
					$link_request = $_SERVER['REDIRECT_URL'];
					preg_match('/\/(en)\/*/i', $link_request,$match);
					$language = (isset($match[1])) ? $match[1] : 'indo';
					
			
					if($language == 'en'){
						echo '<h3 class="sdtitle">Lastest Posts</h3>';
					}
					else{
						echo '<h3 class="sdtitle">Posting terbaru</h3>';
					}
					
					//print_r ($_SERVER);
				?>
                
                <ul>
					<?php
						$recentPosts = new WP_Query();
						$recentPosts->query('showposts=3');
					?>
					<?php while ($recentPosts->have_posts()) : $recentPosts->the_post(); ?>
						<li><span class="date"><?php the_time('d.m.Y') ?>&nbsp;&raquo;&nbsp;</span><a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a></li>
					<?php endwhile; ?>	
                </ul>
                
            </div>
			<?php endif; ?>
			

			<?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar('third-area') ) : else : ?>
			<div class="block">
            	<?php
					//echo "<pre>";
					//print_r ($_SERVER);
					//echo "</pre>";
					$link_request = $_SERVER['REDIRECT_URL'];
					preg_match('/\/(en)\/*/i', $link_request,$match);
					$language = (isset($match[1])) ? $match[1] : 'indo';
					
			
					if($language == 'en'){
						echo '<h3 class="sdtitle">Category</h3>';
					}
					else{
						echo '<h3 class="sdtitle">Kategori</h3>';
					}
					
					//print_r ($_SERVER);
				?>
            	
                <ul>
                	<?php wp_list_cats('sort_column=name&hierarchical=0'); ?>
                </ul>
            </div>
			<?php endif; ?>
			
			<?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar('fourth-area') ) : else : ?>
			<div class="block">
            	<?php
					//echo "<pre>";
					//print_r ($_SERVER);
					//echo "</pre>";
					$link_request = $_SERVER['REDIRECT_URL'];
					preg_match('/\/(en)\/*/i', $link_request,$match);
					$language = (isset($match[1])) ? $match[1] : 'indo';
					
			
					if($language == 'en'){
						echo '<h3 class="sdtitle">UB News</h3>';
					}
					else{
						echo '<h3 class="sdtitle">Berita UB</h3>';
					}
					
					//print_r ($_SERVER);
				?>
                
                <?php
					include_once(ABSPATH . WPINC . '/rss.php');
					$rss = fetch_rss('http://prasetya.ub.ac.id/rss.xml?lang=id');
					$maxitems = 4;
					$items = array_slice($rss->items, 0, $maxitems);
					if (empty($items)) echo 'No RSS items';
					else
					echo '<ul>';
					foreach ( $items as $item ) : ?>
						<li>
							
							<span class="date"><?php $pubdate = strftime("%d.%m.%Y", strtotime($item['pubdate'])); echo $pubdate; ?>&nbsp;&raquo;&nbsp;</span>
							<a href='<?php echo $item['link']; ?>' title='<?php echo $item['title']; ?>'><?php echo $item['title']; ?></a>
							
						</li>			
					<?php endforeach; 
					echo '</ul>';
				?>
            </div>
			<?php endif; ?>
			
			<?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar('first-area') ) : else : ?>
    		<div class="block">
            	
                <h3 class="sdtitle">QuickLink</h3>
                <ul>
                	<li><a href="http://ub.ac.id">UB Official</a></li>
					<li><a href="http://bits.ub.ac.id/">BITS</a></li>
					<li><a href="https://webmail.ub.ac.id/">Webmail</a></li>
					<li><a href="http://prasetya.ub.ac.id/">Prasetya</a></li>
					<li><a href="https://siam.ub.ac.id/">SIAM</a></li>
					<li><a href="https://siado.ub.ac.id/">SIADO</a></li>
					<li><a href="https://simpeg.ub.ac.id/">SIMPEG</a></li>
					<li><a href="http://selma.ub.ac.id/">SELMA</a></li>
					<li><a href="https://siakad.ub.ac.id/wisuda/ ">SIUDA</a></li>
					<li><a href="https://bais.ub.ac.id/">BAIS</a></li>
					<li><a href="https://e-complaint.ub.ac.id/">E-complaint</a></li>
                </ul>
            </div>
			<?php endif; ?>
			
           	
			
    </div>