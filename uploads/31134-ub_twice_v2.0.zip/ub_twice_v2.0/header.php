<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">
	<title><?php bloginfo('name'); ?><?php wp_title(); ?></title>
	<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
	<meta name="generator" content="WordPress <?php bloginfo('version'); ?>" /> <!-- leave this for stats please -->
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="HandheldFriendly" content="true">
	<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
	<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="print" />
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/mobile.css" type="text/css" media="screen" />
	<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/menu/slicknav.css" />
	<!--<script type="text/javascript" src="<?php //bloginfo('template_url'); ?>/js/jquery-1.3.1.min.js"></script>	
	<script type="text/javascript" src="<?php //bloginfo('template_url'); ?>/js/jquery.flexslider-min.js"></script>
	<script type="text/javascript" language="javascript" src="<?php //bloginfo('template_url'); ?>/js/jquery.dropdownPlain.js"></script>-->

	<script src="<?php bloginfo('template_url'); ?>/menu/modernizr.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/menu/jquery.min.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/menu/jquery.slicknav.js"></script>
	<!--<script type="text/javascript">
			$(window).load(function() {
				$('.flexslider').flexslider({
				  animation: "slide",
				  controlsContainer: ".flex-container"
			  });
			});
	</script>-->
    <script type="text/javascript">
	$(document).ready(function(){
		$('#menu').slicknav();
	});
	
	</script>
		
	<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php bloginfo('rss2_url'); ?>" />
	<link rel="alternate" type="text/xml" title="RSS .92" href="<?php bloginfo('rss_url'); ?>" />
	<link rel="alternate" type="application/atom+xml" title="Atom 0.3" href="<?php bloginfo('atom_url'); ?>" />
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
	<?php wp_get_archives('type=monthly&format=link'); ?>
	<?php //comments_popup_script(); // off by default ?>
	<?php wp_head(); ?>
</head>

<body>
<div id="wrapper">

<div id="header">
	
    <div class="toplink">
    	<div class="posisi">
        <ul>
        	<?php
				//echo "<pre>";
				//print_r ($_SERVER);
				//echo "</pre>";
				$link_request = $_SERVER['REDIRECT_URL'];
				preg_match('/\/(en)\/*/i', $link_request,$match);
				$language = (isset($match[1])) ? $match[1] : 'indo';
				$link = substr($_SERVER['REDIRECT_URL'],0);
				
				
		
				if($language == 'en'){
					echo '
						
						<li><a title="UB Official Site" href="http://www.ub.ac.id/" target="_blank">UB Official</a></li>
						<li><a title="BITS UB" href="http://bits.ub.ac.id/" target="_blank">BITS</a></li>
						<li><a title="Mail UB" href="http://webmail.ub.ac.id/" target="_blank">Webmail</a></li>
						<li><a title="Prasetya Online" href="http://prasetya.ub.ac.id/" target="_blank">UB News</a></li>
						<li><a title="Translate to Indonesia" href="'.$_SERVER['REQUEST_URI'].'" >Indonesia</a></li>
					';
				}
				else{
					echo '
						
						<li><a title="UB Official Site" href="http://www.ub.ac.id/" target="_blank">UB Official</a></li>
						<li><a title="BITS UB" href="http://bits.ub.ac.id/" target="_blank">BITS</a></li>
						<li><a title="Mail UB" href="http://webmail.ub.ac.id/" target="_blank">Webmail</a></li>
						<li><a title="Prasetya Online" href="http://prasetya.ub.ac.id/" target="_blank">UB News</a></li>
						<li><a title="Translate to English" href="http://'.$_SERVER['SERVER_NAME'].'/en'. $link.'" >English</a></li>
					';
				}
				
				//print_r ($_SERVER);
			?>
        	
        </ul>
        <div class="clear"></div>
        </div>
        
    </div>
    
    <div class="logo"><a href="<?php bloginfo('url'); ?>"><img src="<?php bloginfo('template_url'); ?>/images/logo-ub.png" alt="logo ub" /></a></div>
    
    <div class="text-logo left">
    	<h1><a href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a></h1>
        <span>&mdash; <?php bloginfo( 'description' ); ?></span>
    </div>
    
    <div class="clear"></div>
    
    <div class="bigmenu">
        <div class="dropdown">
        	<ul>
            	<li><a href="<?php bloginfo('siteurl'); ?>" title="Home">Home</a></li>
            	<?php wp_list_pages('title_li='); ?>
            </ul>
        </div>
    </div>
    

</div>
<div class="mobile-dropdown">
  <ul id="menu" style="margin:5px;">
  	<li><a href="<?php bloginfo('siteurl'); ?>" title="Home">Home</a></li>
    <?php wp_nav_menu( array('menu' => 'Main Menu' )); ?>
  </ul>
</div>