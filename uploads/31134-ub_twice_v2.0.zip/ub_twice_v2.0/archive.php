<?php get_header(); ?>

<div id="main">
	
    
    
   <div class="content right">
        
        <div class="single">
		
			<div class="breadcrumbs">
				<?php wp_breadcrumb(); ?>
			</div>
				
			<?php if (have_posts()) : ?>
            <?php
				$link_request = $_SERVER['REDIRECT_URL'];
				preg_match('/\/(en)\/*/i', $link_request,$match);
				$language = (isset($match[1])) ? $match[1] : 'indo';
				
		
				if($language == 'en'){
					echo '
						<h3 class="sdtitle">Archive :' .get_the_time('F').'&nbsp;'.get_the_time('Y').'</h3>
					';
				}
				else{
					echo '
						<h3 class="sdtitle">Arsip :' .get_the_time('F').'&nbsp;'.get_the_time('Y').'</h3>
					';
				}
			?>
                
                <div class="p1">
                	
					<?php while (have_posts()) : the_post(); ?>
                    <div class="listnews">
                        <div class="title"><h2><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2></div>
                        <div class="entry"><?php the_excerpt(); ?></div>
                        <div class="info">Posted in <?php the_time('d.m.Y') ?> | <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">readmore</a></div>
                        <div class="clear"></div>
                    </div>
					<?php endwhile; ?>
					                    
					<?php endif; ?>
					
					<div class="pages">
						<?php 
							if (function_exists("paginate")) {
								paginate(); 
							}
						?>
					</div>
					
                </div>
                
              </div>
              
        
    </div>
    <?php get_sidebar(); ?>
    <div class="clear"></div>
    
</div>

<?php get_footer(); ?>